
//METAL SLUG 6 Soundbank//
  © SNK Corporation
	Provided by Studio Aqua

This .zip contains all Metal Slug 6 Arcade exclusive sound effects, manually
recorded and edited from the Sound Test via Demul emulation. Sound effects
ported over from previous games are not included. 

No credit required if used!

-Division 六